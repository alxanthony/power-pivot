<?php get_header(); ?>

<div id="lostWrapper">
    <div class="container">
        <h1>404</h1>
        <p class="white">Looks like the page you’re looking for isn’t here. <br/>Click the button below and we’ll take you back home.</p>
        <a href="/" class="button btn-a">Go Back</a>
    </div>
</div>

<?php get_footer(); ?>
